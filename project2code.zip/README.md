# mlproject2
Project for CSE 142

To train the model we used for this project,

1) run the augment_all_images.py script to augment all of the 10k images.
      These images are augmented 5 times each creating 50k augmented images

2) run the classify_all.py script to train our CNN on this data.
      The 50k augmented images are appended to the 10k given images
      The CNN is referred to as CNN 4 layer in the project report

3) the trained model will be saved in a .h5 file
      submission.scv will also be created for submission to kaggle

preprocess.py - script used to create the .npy files for the given 10k data
